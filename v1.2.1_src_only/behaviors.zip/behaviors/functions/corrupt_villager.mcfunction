
setblock ~ ~ ~ air
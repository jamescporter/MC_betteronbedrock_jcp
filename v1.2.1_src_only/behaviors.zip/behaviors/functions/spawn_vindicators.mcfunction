summon vindicator ~ ~ ~
setblock ~ ~ ~ air